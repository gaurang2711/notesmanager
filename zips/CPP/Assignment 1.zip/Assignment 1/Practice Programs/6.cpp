#include<iostream>

using namespace std;

int main(){
	int n, ogN, revN;
	cout<<"Enter a number: ";
	cin>>n;
	
	ogN = n;
	
	while(n > 0){
		int dig = n % 10;
		revN = (revN * 10) + dig;
		n = n / 10;
	}
	
	if(ogN == revN){
		cout<<"Yes! it is Palindrome";
	}
	else{
		cout<<"No! it is not palindrome";
	}
	
	return 0;
}