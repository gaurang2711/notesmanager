#include <iostream>

int main() {
    int N;

    std::cout << "Enter the total number of rows for the diamond (odd positive integer): ";
    std::cin >> N;

    if (N <= 0 || N % 2 == 0) {
        std::cout << "Invalid input. Please enter a positive odd integer." << std::endl;
        return 1;
    }

    int mid = (N + 1) / 2;

    for (int row = 1; row <= N; ++row) {
        int num_leading_spaces;
        if (row <= mid) {
            num_leading_spaces = mid - row;
        } else {
            num_leading_spaces = row - mid;
        }

        for (int s = 0; s < num_leading_spaces; ++s) {
            std::cout << " ";
        }

        if (row == 1 || row == N) {
            std::cout << "*";
        } else if (row == mid) {
            std::cout << "* * *";
        } else {
            std::cout << "*";
            int diff_from_mid;
            if (row < mid) {
                diff_from_mid = mid - row;
            } else {
                diff_from_mid = row - mid;
            }
            int num_internal_spaces = (2 * diff_from_mid) - 1;

            for (int s = 0; s < num_internal_spaces; ++s) {
                std::cout << " ";
            }
            std::cout << "*";
        }
        std::cout << std::endl;
    }

    return 0;
}