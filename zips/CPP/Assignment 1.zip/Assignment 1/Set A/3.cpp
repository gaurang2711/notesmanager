#include<iostream>

using namespace std;

int main(){
    int n1, n2;
    char op;
        cout<<"Select an operator (+, -, *, /, E to exit)): ";
        cin>>op;
        cout<<"Enter first number: ";
        cin>>n1;
        cout<<"Enter second number: ";
        cin>>n2;

        switch (op)
        {
        case '+':
            cout<<n1<<" + "<<n2<<" = "<<n1+n2<<endl;
            break;
        
        case '-':
            cout<<n1<<" - "<<n2<<" = "<<n1-n2<<endl;
            break;
        
        case '*':
            cout<<n1<<" * "<<n2<<" = "<<n1*n2<<endl;
            break;
        
        case '/':
            cout<<n1<<" / "<<n2<<" = "<<n1/n2<<endl;
            break;
        
        case 'E':
            cout<<"Exiting the program."<<endl;
            return 0;

        default: cout<<"Invalid operation";
            break;
        }
    return 0;
}