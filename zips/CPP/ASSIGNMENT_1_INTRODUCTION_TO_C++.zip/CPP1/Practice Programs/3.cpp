#include<iostream>

using namespace std;

int main(){
	int n;
	cout<<"Enter number: ";
	cin>>n;
	
	if(n%2 == 0){
		cout<<n<<" is even";
	}
	else{
		cout<<n<<" is odd";
	}

	cout<<"\n--CODED BY GAURANG DALAL--\n";
	
	return 0;
}